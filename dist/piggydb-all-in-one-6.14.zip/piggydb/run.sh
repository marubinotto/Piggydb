#!/bin/sh

java -Dpiggydb.database.prefix=file:~/piggydb -Dpiggydb.database.name=piggydb -Dpiggydb.enableAnonymous=false -jar winstone.jar --warfile=piggydb-6.14.war $1 $2 $3 $4 $5
